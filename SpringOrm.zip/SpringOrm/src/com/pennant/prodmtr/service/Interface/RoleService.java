package com.pennant.prodmtr.service.Interface;

import java.util.List;

import com.pennant.prodmtr.model.Entity.Role;

public interface RoleService {
	List<Role> getAllRoles();

	// Other methods for role-related operations
}
