package com.pennant.prodmtr.Dao.Impl;

public interface FunctionalunitDAO {

}
