package com.pennant.prodmtr.model.Dto;

public class PTFilterCriteria {

	private Short projectId;
	private Integer resourceId;

	public Short getProjectId() {
		return projectId;
	}

	public void setProjectId(Short projectId) {
		this.projectId = projectId;
	}

	public Integer getResourceId() {
		return resourceId;
	}

	public void setResourceId(Integer resourceId) {
		this.resourceId = resourceId;
	}
}
