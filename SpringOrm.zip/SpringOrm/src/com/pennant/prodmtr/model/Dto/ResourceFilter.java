package com.pennant.prodmtr.model.Dto;

public class ResourceFilter {

	private Short roleFilter;

	private Short projectFilter;

	public Short getRoleFilter() {
		return roleFilter;
	}

	public void setRoleFilter(Short roleFilter) {
		this.roleFilter = roleFilter;
	}

	public Short getProjectFilter() {
		return projectFilter;
	}

	public void setProjectFilter(Short projectFilter) {
		this.projectFilter = projectFilter;
	}
}