package com.pennant.prodmtr.model;

public class ModuleSummary {
	private int modlId;
	private String modlName;
	private double totalWorkingHours;

	public int getModlId() {
		return modlId;
	}

	public void setModlId(int modlId) {
		this.modlId = modlId;
	}

	public String getModlName() {
		return modlName;
	}

	public void setModlName(String modlName) {
		this.modlName = modlName;
	}

	public double getTotalWorkingHours() {
		return totalWorkingHours;
	}

	public void setTotalWorkingHours(double totalWorkingHours) {
		this.totalWorkingHours = totalWorkingHours;
	}

}
