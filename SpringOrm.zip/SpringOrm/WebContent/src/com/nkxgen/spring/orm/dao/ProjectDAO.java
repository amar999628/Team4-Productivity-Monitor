package com.nkxgen.spring.orm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;

import com.nkxgen.spring.orm.model.Project;

@Component
public class ProjectDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public List<Project> getAllProjects() {
		return entityManager.createQuery("SELECT p FROM Project p", Project.class).getResultList();
	}

	public Project findById(short id) {
		return entityManager.find(Project.class, id);
	}

}
