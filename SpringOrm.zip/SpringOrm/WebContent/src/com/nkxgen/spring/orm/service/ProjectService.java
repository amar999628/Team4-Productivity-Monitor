package com.nkxgen.spring.orm.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nkxgen.spring.orm.dao.ProjectDAO;
import com.nkxgen.spring.orm.model.Project;

@Component
@Transactional
public class ProjectService {

    @Autowired
    private ProjectDAO projectDAO;

    public void setProjectDAO(ProjectDAO projectDAO) {
        this.projectDAO = projectDAO;
    }

    @Transactional
    public List<Project> getAllProjects() {
        return projectDAO.getAllProjects();
    }
}
